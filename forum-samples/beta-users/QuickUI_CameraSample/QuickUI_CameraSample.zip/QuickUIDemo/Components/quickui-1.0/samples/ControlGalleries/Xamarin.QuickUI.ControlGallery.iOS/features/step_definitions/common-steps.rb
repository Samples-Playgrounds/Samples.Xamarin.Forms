# Navigation steps
Given /^I am on the Main Screen$/ do
  check_element_exists("button marked:'Kitchen Sink'")
  take_screenshot
end

# Scrolling and selection in scroll view
Then /^I navigate to the "(.*?)" Gallery$/ do |gallery|
  check_element_exists("button marked:'Kitchen Sink'")
  scroll_down_for_label(gallery)
  take_screenshot
  touchQuery = "label marked:'#{gallery}'"
  long_touch_and_wait(touchQuery)
end

Then /^I scroll down to label "(.*?)"$/ do |label|
  scroll_down_for_label(label)
  take_screenshot
end

Then /^I scroll up to label "(.*?)"$/ do |label|
  scroll_up_for_label(label)
  take_screenshot
end

And /^I see that "(.*?)" is not enabled$/ do |view|
  fail ('Element is enabled') if query("view marked:'#{view}'", 'isEnabled').first == "1"
  take_screenshot
end

And /^I see the "(.*?)" Button$/ do |btn|
  wait_for(:timeout => 5, :post_timeout => 0.5) { element_exists("button marked:'#{btn}'") }
  take_screenshot
end

And /^I see the label "(.*?)"$/ do |view|
  wait_for(:timeout => 5, :post_timeout => 0.5) { element_exists("label text:'#{view}'") }
  take_screenshot
end

And /^I touch the label "(.*?)"$/ do |view|
  wait_for(:timeout => 5, :post_timeout => 0.5) { element_exists("label text:'#{view}'") }
  touch ("label text:'#{view}'")
  take_screenshot
end

And /^I press the "(.*?)" Button/ do |btn|
  wait_for(:timeout => 5, :post_timeout => 0.5) { element_exists("view marked:'#{btn}'") }
  tap btn
  take_screenshot
end

And /^I see an Alert$/ do
  wait_for(:timeout => 5, :post_timeout => 0.5) { element_exists("view:'UIAlertView'") }
  take_screenshot
end

Then /^I see an entry marked "(.*?)"$/ do |placeholder|
  wait_for(:timeout => 5, :post_timeout => 0.5) { element_exists("textField placeholder:'#{placeholder}'") }
  take_screenshot
end

# Helper Functions
def take_screenshot
  screenshot_embed
end


def get_num_rows(scrollView)
  i = 0
  each_cell(:animate => false, :post_scroll => 0) do
    i += 1
  end
  puts("Number of rows in scroll view: #{i}")
  return i
end

def scroll_down_for_label(labelToFind)
  elementToFind = "scrollView descendant label marked:'#{labelToFind}'"
  wait_poll({:until_exists => elementToFind, :timeout => 30}) do
    scroll("scrollView", :down)
    take_screenshot
  end
end

def scroll_up_for_label(labelToFind)
  elementToFind = "scrollView descendant label marked:'#{labelToFind}'"
  wait_poll({:until_exists => elementToFind, :timeout => 30}) do
    scroll("scrollView", :up)
    take_screenshot
  end
end

def touch_and_wait(element)
    sleep(0.1)
    touch(element)
    take_screenshot
    sleep(0.1)
end

def long_touch_and_wait(element)
  sleep(0.4)
  touch(element)
  take_screenshot
  sleep(0.4)
end