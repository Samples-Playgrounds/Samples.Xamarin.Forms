Then /^I am at the Slider Gallery$/ do
  sliderCount = query("Slider").count
  fail('You are not at the Gallery') if (sliderCount != 3)
  take_screenshot
end

And /^I move slider "(.*?)" to the right$/ do |sliderIndex|
  case sliderIndex
    when "1"
      playback "move_slider_one_right"
    when "2"
      playback "move_slider_two_right"
    when "3"
      playback "move_slider_three_right"
    else
  end
end

Then /^The value of slider "(.*?)" changed$/ do |sliderIndex|
  sliderValue = query("Slider", "value")[sliderIndex.to_i - 1]
  fail ('Slider value should change on slide') if (sliderValue == 0)
end

Then /^The value of slider "(.*?)" did not change$/ do |sliderIndex|
  sliderValue = query("Slider", "value")[sliderIndex.to_i - 1]
  fail ('Slider value should not change on slide') if (sliderValue != 0)
end