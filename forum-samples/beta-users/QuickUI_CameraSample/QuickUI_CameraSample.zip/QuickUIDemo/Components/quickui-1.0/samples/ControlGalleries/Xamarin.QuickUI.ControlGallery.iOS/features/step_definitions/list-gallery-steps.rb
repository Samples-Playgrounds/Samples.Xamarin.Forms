Then /^I am at the List Gallery$/ do
  view_with_mark_exists("8")
  take_screenshot
end

And /^I click an element twice in a row$/ do
  elementToTouch = "label index:4"
  valueBeforeTouch = query(elementToTouch, 'text').first.to_i
  long_touch_and_wait(elementToTouch)
  take_screenshot
  valueAfterTouch = query(elementToTouch, 'text').first.to_i
  long_touch_and_wait(elementToTouch)
  take_screenshot
  valueAfterTouchTwice = query(elementToTouch, 'text').first.to_i
  fail('Can only increment once before clicking on another item') if valueAfterTouch != valueAfterTouchTwice
end

And /^I click 0, 1, 2, 3, 4$/ do
  for i in 0..4 do
    elementToTouch = "label index:#{i}"
    valueBeforeTouch = query(elementToTouch, 'text').first.to_i
    long_touch_and_wait(elementToTouch)
    take_screenshot
    valueAfterTouch = query(elementToTouch, 'text').first.to_i
    fail('Value did not increment') if (valueAfterTouch != (valueBeforeTouch + 1))
  end
end

And /^I click 0, 1, 2, 3, 4, 5$/ do
  for i in 0..5 do
    elementToTouch = "label index:#{i}"
    valueBeforeTouch = query(elementToTouch, 'text').first.to_i
    long_touch_and_wait(elementToTouch)
    valueAfterTouch = query(elementToTouch, 'text').first.to_i
    if i != 5
      fail('Value did not increment') if (valueAfterTouch != (valueBeforeTouch + 1))
    end
  end
end

And /^The values are reset$/ do
  for i in 0..5
    elementToCheck = "label index:#{i}"
    elementValue = query(elementToCheck, 'text').first.to_i
    fail('Values were not reset by clicking a five') if (elementValue != i)
  end
end

And /^I click "(.*?)"$/ do |index|
  elementToTouch = "label index:#{index}"
  touch_and_wait(elementToTouch)
end

Then /^Element "(.*?)" should be selected$/ do |index|
  isHighlighted = query("label index:#{index}", 'isHighlighted').first.to_i
  fail('Element not selected') if (isHighlighted != 1)
end