And /^I am at the Button Gallery$/ do
	check_element_exists("button marked:'Alert'")
  take_screenshot
end
