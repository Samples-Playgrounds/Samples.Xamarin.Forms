And /^I am at the Entry Gallery$/ do
  check_element_exists("textField placeholder:'Normal'")
  check_element_exists("textField placeholder:'Password'")
  check_element_exists("textField placeholder:'Activation'")
  check_element_exists("textField placeholder:'Disabled'")
  check_element_exists("textField placeholder:'Transparent'")
  check_element_exists("button marked:'Toggle Secure'")
  check_element_exists("button marked:'Change Placeholder'")
  check_element_exists("button marked:'Focus First'")
  take_screenshot
end

Then /^Disabled text field exists$/ do
  if (query("textField isEnabled:0") != query("textField placeholder:'Disabled'"))
    screenshot_and_raise "Disabled textfield should be disabled but is not"
  end
end

Then /^Enter a secure password$/ do
  touch("textField placeholder:'Password'")
  take_screenshot
  keyboard_enter_text "PASSWORD"
end

Then /^I check the transparent entry$/ do
   check_element_exists("textField placeholder:'Transparent'")
end

Then /^Toggle Secure$/ do
  long_touch_and_wait ("view marked:'Toggle Secure'")
  long_touch_and_wait ("view marked:'Toggle Secure'")
end

Then /^I check the transparent entry$/ do
   check_element_exists("textField placeholder:'Transparent'")
end


