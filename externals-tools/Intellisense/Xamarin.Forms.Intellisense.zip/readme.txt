Copy the two Design.dll files into the following folders inside the packages\Xamarin.Forms[version] folder:

  lib\portable-win+net45+wp80+win81+wpa81+MonoAndroid10+MonoTouch10+Xamarin.iOS10\Design\
  lib\MonoAndroid10\Design\
  lib\Xamarin.iOS10\Design\
  lib\MonoTouch10\Design\
  lib\WP80\Design\
  lib\wpa81\Design\
  lib\win81\Design\
  
That will enable XF native XAML intellisense for all XF built-in types.