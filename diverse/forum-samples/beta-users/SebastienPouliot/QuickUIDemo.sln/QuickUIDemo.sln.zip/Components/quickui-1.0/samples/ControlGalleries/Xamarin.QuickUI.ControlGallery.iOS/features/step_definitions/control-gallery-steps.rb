Then /^All the galleries are present$/ do
  labels = [
      "Kitchen Sink",
      "Button",
      "Label",
      "Image",
      "Slider",
      "Entry",
      "Search Bar",
      "Switch",
      "Date Picker",
      "Editor",
      "Progress Bar",
      "Scroll View",
      "Tabbed Page",
      "Toolbar",
      "Activity Indicator",
      "Frame",
      "Map",
      "View Cell",
      "UnEven View Cell",
      "CarouselPage",
      "Navigation Menu",
      "Web View",
      "List",
      "Stack Layout",
      "Absolute Layout",
      "Open URI",
      "Settings",
      "Minimum Size"
  ]
  for label in labels do
    scroll_down_for_label(label)
  end
  take_screenshot
end

And /^I navigate to each non-web gallery$/ do
  labels = [
      "Kitchen Sink",
      "Button",
      "Label",
      "Image",
      "Slider",
      "Entry",
      "Search Bar",
      "Switch",
      "Date Picker",
      "Editor",
      "Progress Bar",
      "Scroll View",
      "Tabbed Page",
      "Toolbar",
      "Activity Indicator",
      "Frame",
      "Map",
      "View Cell",
      "UnEven View Cell",
      "CarouselPage",
      "Navigation Menu",
      "List",
      "Stack Layout",
      "Absolute Layout",
      "Settings",
      "Minimum Size"
  ]
  for label in labels do
    scroll_down_for_label(label)
    tap (label)
    sleep(0.5)
    swipe("right", "view marked:'UINavigationBar'")
    sleep(0.3)
    take_screenshot
    swipe("left", "view marked:'UINavigationBar'")
    sleep(0.3)
    tap ("iOS Controls")
    sleep(0.5)
  end

end