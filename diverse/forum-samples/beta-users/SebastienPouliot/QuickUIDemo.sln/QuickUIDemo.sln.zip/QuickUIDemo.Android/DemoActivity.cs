﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using QuickUIDemo;
using Xamarin.QuickUI;
using Xamarin.QuickUI.Platform.Android;

namespace QuickUIDemo.Android
{
    /*
	[Activity (Label = "QuickUIDemo.Android", Icon = "@drawable/icon")]
    public class DemoActivity : MvxAndroidActivity
	{
		protected override void OnCreate (Bundle bundle)
		{
            base.OnCreate (bundle);

			QuickUI.Init (this, bundle);
			SetPage (DemoApp.GetMainPage ());
		}
	}
    */
}

