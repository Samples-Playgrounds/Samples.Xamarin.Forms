And /^I am at the Label Gallery$/ do
  check_element_exists("label marked:'Normal Label'")
  take_screenshot
end

Then /^All the labels are present$/ do
  labels = [
      "Center Label",
      "Right Label",
      "Move On Click",
      "Click Label",
      "Rotate Label",
      "Transparent Label",
      "Color Change",
      "Micro Label",
      "Small Label",
      "Medium Label",
      "Large Label",
      "Custom Font",
  ]
  for label in labels do
    wait_for(:timeout => 5) { element_exists("label text:'#{label}'") }
  end
  take_screenshot
end

# Check label and Alignment
Then /^The "(.*?)" is "(.*?)" aligned$/ do |label, alignment|
  alignmentTypeNum = alignmentType(alignment)
  queryString = "label text:'" + label + "'"
  alignmentProperty = query(queryString, 'textAlignment').first
  fail('Element is not aligned properly') if (alignmentProperty != alignmentProperty)
  take_screenshot
end

# Check label and corresponding font-size
Then /^The "(.*?)" has a "(.*?)" size$/ do |label, size|
  pixelSize = labelSize(size).to_i
  labelFontSize = parseFont(label, "font-size")
  labelFontSize = labelFontSize[0][0].to_i
  fail('Label does not match size') if (pixelSize != labelFontSize)
  take_screenshot
end

### Helper functions ###
def alignmentType(typeString)
  alignmentType = -1
  case typeString
    when 'left'
      alignmentType = 0
    when 'center'
      alignmentType = 1
    when 'right'
      alignmentType = 2
  end
  return alignmentType
end

def labelSize(sizeString)
  size = -1
  case sizeString
    when 'micro'
      size = 12
    when 'small'
      size = 14
    when 'medium'
      size = 17
    when 'large'
      size = 22
  end
  return size
end

def parseFont(label, property)
  elementToScan = property
  queryString = "label text:'" + label + "'"
  fontObject = query(queryString, 'font').to_s
  # extract font size from query object
  fontPixelSize = fontObject.scan(/font-size: (\d+)px/)
  return fontPixelSize
end
